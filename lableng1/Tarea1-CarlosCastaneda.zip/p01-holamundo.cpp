// Programa que envia un saludo
// Carlos Castaneda Ramirez
// 4 de Septiembre 2020

#include <stdio.h> // Carga libreria

main()
{
	// Inicio del programa
	printf("\n"); // se salta una linea
	printf("Bienvenidos al Lenguaje C\n\n");
	printf("=============================");
	printf("\n ");
	printf("\n Primer Programa: \n Hola Mundo Cruel\n");
}


